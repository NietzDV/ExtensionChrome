var imgs = document.getElementsByTagName("img");
 var a = Math.floor(Math.random() * 3 + 1);

	for(var i=0, l=imgs.length; i<l; i++){
		a = Math.floor(Math.random() * 5 + 1);
	if(a ==1){
     imgs[i].src = "http://www.etec.eaj.ufrn.br/wp-content/uploads/2017/07/DSCN1638.jpg"
    }
if(a == 2){
	imgs[i].src = "https://www.emaisgoias.com.br/wp-content/uploads/2018/07/20180727191149207351o-620x450.jpeg"
   }
if(a == 3){
	imgs[i].src = "https://www.etec.eaj.ufrn.br/wp-content/uploads/2019/03/Especialização-em-Tecnologias-Educacionais-2.jpg"
  }
  if(a == 4){
	  imgs[i].src ="http://issoeamazonas.com.br/wp-content/uploads/2019/07/tigresa.png"

  }
  if(a == 5){
	imgs[i].src ="https://domtotal.com/img/noticias/2010-05/217435_42533.jpg"
	
}
	}